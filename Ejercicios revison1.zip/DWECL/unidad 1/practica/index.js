/* if (true) 
{
    var miVariable = 3;
}
 */




/*  var otraVariable = 5;
 const otra1Variable = 8;

console.log(miVariable);
console.warn("esto es una aviso"); */

/* let $mivar = 33;
document.write("<h1>valor de la variable " + $mivar+"</h1>"); */
/* function ejercicio1 ()
{
var mivariable = "Jose";
if (mivariable)
{
    console.log("Variable contains ${mivariable}");
}

} */

/* BUCLES */

/*for (let i=0; i<10; i++){
    for (let j = 0; j<5; j++){
        console.log(i * j);
    }
} */

/* let i = 0;
do {
    i += 1;
    console.log(i);
}while (i<5);  */

function suma(v1,v2,v3){
    return v1+v2+v3;
}

miArray = []