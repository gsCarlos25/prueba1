let varcelsius = 25;
document.write(varcelsius + " Cº = " + ((varcelsius * 9 / 5) + 32) + " F" + "</br>");
let varfar = 100;
document.write(varfar + " F = " + ((varfar - 32) * 5 / 9) + " Cº");