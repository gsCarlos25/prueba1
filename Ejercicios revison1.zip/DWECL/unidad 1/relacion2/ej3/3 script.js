let varRadio = 4;
document.write("The radius is: "+(2 * 3.1416 * varRadio) + "</br>");
document.write("The area is: " + (3.1416 * varRadio ** 2));