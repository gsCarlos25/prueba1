let var1 = 3;
let var2 = 10;
document.write("El valor de la variable 1 es: "+var1 + "</br>");
document.write("El valor de la variable 2 es: "+var2+ "</br>");
document.write("La suma es: "+(var1 + var2) + "</br>");
document.write("La resta es: "+(var1 - var2) + "</br>");
document.write("La multiplicacion es: "+(var1 * var2) + "</br>");
document.write("La division es: "+(var1 / var2) + "</br>");
