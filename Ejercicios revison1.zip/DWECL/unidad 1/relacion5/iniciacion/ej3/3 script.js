function saludo() {
    var nombre = prompt("Cómo te llamas: ");
    alert(`Hola ${nombre}`);
}
saludo()