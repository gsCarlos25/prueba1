pokemon = [{nombre='Picachu',tipo='electrico'},
            {nombre='snorlax',tipo='normal'},
            {nombre='charmander',tipo='fuego'},
            {nombre='zapdos',tipo='electrico'},
            {nombre='sceptile',tipo='planta'}]

(pokemon.sort((a,b)=>{
    if (a.tipo > b.tipo)
        return 1
    else if (a.tipo < b.tipo)
        return -1
    else
        if (a.nombre > b.nombre)
            return 1
        else if (a.nombre < b.nombre)
            return -1
        else
            return 0
}))

for (i of pokemon)
    document.write(pokemon[i])
