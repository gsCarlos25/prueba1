/* ejercicio 2 */

// c
document.write(`Nuemro de imagenes: ${document.images.length}<br>`);

// d 

// e
document.write(`Numero de enlaces: ${document.anchors.length}`);
